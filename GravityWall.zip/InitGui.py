# -*- coding: utf-8 -*-
import os
import FreeCAD
import FreeCADGui

class GravityWallWorkbench(Workbench):
    MenuText = "GravityWall"
    ToolTip = "Gravity Retaining Wall Tool"
    
    # メインアイコンの指定（GravityWall.pngを使用）
    # path: /Mod/GravityWall/icons/GravityWall.png
    icon_path = os.path.join(FreeCAD.getUserAppDataDir(), "Mod", "GravityWall", "icons", "GravityWall.png")
    Icon = icon_path

    def Initialize(self):
        """ワークベンチ起動時にツールを読み込み、UIを構成する"""
        # toolsフォルダから各機能のPythonファイルをインポートしてコマンドを有効化
        from tools import GravityWallTool
        from tools import GravityWallBaseTool      # 基礎コンクリート作成ツール
        from tools import GravityWallCurveTool     # カーブ擁壁作成ツール（新規追加）
        from tools import GravityWallVolumeTool
        from tools import GravityWallFormworkTool
        
        # CommandList.py から登録するコマンドのリストを取得
        import CommandList
        
        # ツールバー「Wall Tools」を作成し、リストにあるボタンを表示
        self.appendToolbar("Wall Tools", CommandList.commands)
        
        # メニュー「Gravity Wall Menu」を作成し、リストにある項目を表示
        self.appendMenu("Gravity Wall Menu", CommandList.commands)

    def GetClassName(self):
        return "Gui::PythonWorkbench"

# ワークベンチをFreeCADのGUIに登録
Gui.addWorkbench(GravityWallWorkbench())