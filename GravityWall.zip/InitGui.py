# -*- coding: utf-8 -*-
import os
import sys
import FreeCAD
import FreeCADGui

# 【対策1】FreeCADが自作ツール（toolsフォルダやCommandList.py）を見つけられるように検索パス（sys.path）に追加
# 変数エラーを防ぐため、1行でパスを組み立てて追加します
if os.path.join(FreeCAD.ConfigGet("UserModFolder"), "GravityWall") not in sys.path:
    sys.path.append(os.path.join(FreeCAD.ConfigGet("UserModFolder"), "GravityWall"))


# 【対策2】クラスの継承元を正しく「FreeCADGui.Workbench」に指定
class GravityWallWorkbench(FreeCADGui.Workbench):
    MenuText = "GravityWall"
    ToolTip = "Gravity Retaining Wall Tool"
    
    # 【対策3】クラス定義の段階では一旦空文字にし、Initializeの中で確実にパスを通します
    # これにより、FreeCAD 1.1での「アイコンが見つからない」バグや変数エラーを完全に回避します
    Icon = ""

    def Initialize(self):
        """ワークベンチ起動時にツールを読み込み、UIを構成する"""
        
        # 【対策3の続き】ワークベンチが起動するこの瞬間に、正しい絶対パスを使ってアイコンを設定
        _mod_dir = FreeCAD.ConfigGet("UserModFolder")
        self.Icon = os.path.join(_mod_dir, "GravityWall", "icons", "GravityWall.png").replace('\\', '/')

        try:
            # toolsフォルダから各機能のPythonファイルをインポートしてコマンドを有効化
            from tools import GravityWallTool
            from tools import GravityWallBaseTool      # 基礎コンクリート作成ツール
            from tools import GravityWallCurveTool     # カーブ擁壁作成ツール（新規追加）
            from tools import GravityWallVolumeTool
            from tools import GravityWallFormworkTool
            
            # CommandList.py から登録するコマンドのリストを取得
            import CommandList
            
            # ツールバー「Wall Tools」を作成し、リストにあるボタンを表示
            self.appendToolbar("Wall Tools", CommandList.commands)
            
            # メニュー「Gravity Wall Menu」を作成し、リストにある項目を表示
            self.appendMenu("Gravity Wall Menu", CommandList.commands)

        except Exception as e:
            from FreeCAD import Console
            Console.PrintError(f"GravityWallワークベンチの読み込みに失敗しました: {str(e)}\n")

    def GetClassName(self):
        return "Gui::PythonWorkbench"


# 【対策4】正しく「FreeCADGui.addWorkbench」を使って登録
FreeCADGui.addWorkbench(GravityWallWorkbench())