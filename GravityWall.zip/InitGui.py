# -*- coding: utf-8 -*-
import os
import FreeCAD
import FreeCADGui

class GravityWallWorkbench(Workbench):
    MenuText = "GravityWall"
    ToolTip = "Gravity Retaining Wall Tool"
    
    # メインアイコンの指定
    icon_path = os.path.join(FreeCAD.getUserAppDataDir(), "Mod", "GravityWall", "icons", "GravityWall.png")
    Icon = icon_path

    def Initialize(self):
        """ワークベンチ起動時にツールを読み込む"""
        import CommandList
        # toolsフォルダから各機能をインポートしてコマンドを有効化
        from tools import GravityWallTool
        from tools import GravityWallVolumeTool
        from tools import GravityWallFormworkTool
        
        # ツールバーとメニューにコマンドを表示
        self.appendToolbar("Wall Tools", CommandList.commands)
        self.appendMenu("Gravity Wall Menu", CommandList.commands)

    def GetClassName(self):
        return "Gui::PythonWorkbench"

# ワークベンチを登録
Gui.addWorkbench(GravityWallWorkbench())