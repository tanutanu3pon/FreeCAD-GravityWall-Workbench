# -*- coding: utf-8 -*-
import FreeCAD as App
import FreeCADGui
import Part
import os
from PySide import QtGui, QtCore

class GravityWallDialog(QtGui.QDialog):
    def __init__(self):
        super(GravityWallDialog, self).__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("擁壁寸法入力")
        layout = QtGui.QGridLayout()

        # デフォルト値を背面ほぼ垂直(0.02)に設定
        self.fields = {
            'h1': ('手前側の高さ Z1 (mm)', '3000.0'),
            'h2': ('奥側の高さ Z2 (mm)', '3500.0'),
            'w': ('天端幅 X (mm)', '500.0'),
            'l': ('延長 Y (mm)', '5000.0'),
            'n': ('前面勾配 (1:n)', '0.5'), 
            'm': ('背面勾配 (1:n)', '0.02')   
        }
        
        self.inputs = {}
        for i, (key, (label_text, default_val)) in enumerate(self.fields.items()):
            layout.addWidget(QtGui.QLabel(label_text), i, 0)
            self.inputs[key] = QtGui.QLineEdit(default_val)
            layout.addWidget(self.inputs[key], i, 1)

        btn_box = QtGui.QDialogButtonBox(QtGui.QDialogButtonBox.Ok | QtGui.QDialogButtonBox.Cancel)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box, len(self.fields), 0, 1, 2)
        self.setLayout(layout)

    def get_values(self):
        return {key: float(edit.text()) for key, edit in self.inputs.items()}

class GravityWallCommand:
    def GetResources(self):
        current_dir = os.path.dirname(__file__)
        icon_path = os.path.normpath(os.path.join(current_dir, "..", "icons", "GravityWall.png"))
        return {
            'Pixmap': icon_path,
            'MenuText': "重力式擁壁のモデルを作成",
            'ToolTip': "前面勾配の端点(底面)を原点(0,0,0)として作成します"
        }

    def Activated(self):
        form = GravityWallDialog()
        if form.exec_() == QtGui.QDialog.Accepted:
            vals = form.get_values()
            self.create_wall(vals)

    def create_wall(self, v):
        h1, h2, w, l, n, m = v['h1'], v['h2'], v['w'], v['l'], v['n'], v['m']

        def calculate_wire(h, y_pos):
            # 前面勾配の端点（底面の角）を原点 X=0 に固定する計算
            
            x1 = 0.0                      # p1: 前面底角（ここが原点）
            x4 = h * n                    # p4: 前面天端角（底角から勾配分だけ右へ）
            x3 = x4 + w                   # p3: 背面天端角（天端角から幅分だけ右へ）
            x2 = x1 + (h * n + w + h * m) # p2: 背面底角（全体の底幅分だけ右へ）
            
            # 頂点定義
            p1 = App.Vector(x1, y_pos, 0) # 底面・前面（原点）
            p2 = App.Vector(x2, y_pos, 0) # 底面・背面
            p3 = App.Vector(x3, y_pos, h) # 天端・背面
            p4 = App.Vector(x4, y_pos, h) # 天端・前面
            
            return Part.makePolygon([p1, p2, p3, p4, p1])

        # 断面作成
        wire1 = calculate_wire(h1, 0)
        wire2 = calculate_wire(h2, l)

        # 立体化
        wall_loft = Part.makeLoft([wire1, wire2], True)

        doc = App.activeDocument() or App.newDocument()
        obj = doc.addObject("Part::Feature", "GravityWall")
        obj.Shape = wall_loft
        doc.recompute()

FreeCADGui.addCommand('GravityWall_Create', GravityWallCommand())