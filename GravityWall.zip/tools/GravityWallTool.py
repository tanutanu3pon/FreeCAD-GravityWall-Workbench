# -*- coding: utf-8 -*-
import FreeCAD as App
import FreeCADGui
import Part
import os
from PySide import QtGui, QtCore

class GravityWallDialog(QtGui.QDialog):
    def __init__(self):
        super(GravityWallDialog, self).__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("擁壁寸法入力 (前後高低差対応)")
        layout = QtGui.QGridLayout()

        self.fields = {
            'h1': ('手前側の高さ Z1 (mm)', '3000.0'),
            'h2': ('奥側の高さ Z2 (mm)', '3500.0'),
            'w': ('天端幅 X (mm)', '500.0'),
            'l': ('延長 Y (mm)', '5000.0'),
            'n': ('前面勾配 (1:n)', '0.02'), # 道路側から土砂側へ倒れる
            'm': ('背面勾配 (1:m)', '0.5')   # 土砂側から道路側へ倒れる
        }
        
        self.inputs = {}
        for i, (key, (label_text, default_val)) in enumerate(self.fields.items()):
            layout.addWidget(QtGui.QLabel(label_text), i, 0)
            self.inputs[key] = QtGui.QLineEdit(default_val)
            layout.addWidget(self.inputs[key], i, 1)

        btn_box = QtGui.QDialogButtonBox(QtGui.QDialogButtonBox.Ok | QtGui.QDialogButtonBox.Cancel)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box, len(self.fields), 0, 1, 2)

        self.setLayout(layout)

    def get_values(self):
        return {k: float(v.text()) for k, v in self.inputs.items()}

class GravityWallCommand:
    def GetResources(self):
        icon_path = os.path.join(App.getUserAppDataDir(), "Mod", "GravityWall", "icons", "GravityWall.png")
        return {
            'Pixmap': icon_path,
            'MenuText': "重力式擁壁のモデルを作成",
            'ToolTip': "前面勾配は土砂側へ、背面勾配は道路側へ倒れます"
        }

    def Activated(self):
        form = GravityWallDialog()
        if form.exec_() == QtGui.QDialog.Accepted:
            vals = form.get_values()
            self.create_wall(vals)

    def create_wall(self, v):
        h1, h2, w, l, n, m = v['h1'], v['h2'], v['w'], v['l'], v['n'], v['m']

        def calculate_wire(h, y_pos):
            # 底幅を計算（天端幅 + 前面張り出し + 背面張り出し）
            # 勾配分だけ底が広がる設計にします
            # p1(左下), p2(右下), p3(右上), p4(左上)
            
            # 左下（道路側）を原点(0, y_pos, 0)とする
            p1 = App.Vector(0, y_pos, 0)
            # 右下（土砂側）
            p2 = App.Vector(h * n + w + h * m, y_pos, 0)
            # 右上（背面天端：底面より h*m だけ内側へ戻る）
            p3 = App.Vector(h * n + w, y_pos, h)
            # 左上（前面天端：底面より h*n だけ内側へ進む）
            p4 = App.Vector(h * n, y_pos, h)
            
            return Part.makePolygon([p1, p2, p3, p4, p1])

        # 手前側(Y=0)と奥側(Y=l)のワイヤーを作成
        wire1 = calculate_wire(h1, 0)
        wire2 = calculate_wire(h2, l)

        # ロフトで立体化
        wall_loft = Part.makeLoft([wire1, wire2], True)

        doc = App.activeDocument() or App.newDocument()
        obj = doc.addObject("Part::Feature", "GravityWall")
        obj.Shape = wall_loft
        doc.recompute()

    def IsActive(self):
        return True

FreeCADGui.addCommand('GravityWall_Create', GravityWallCommand())