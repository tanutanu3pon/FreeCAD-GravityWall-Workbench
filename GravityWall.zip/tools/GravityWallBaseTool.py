# -*- coding: utf-8 -*-
import FreeCAD as App
import FreeCADGui
import Part
import os
from PySide import QtGui, QtCore

class GravityWallBaseDialog(QtGui.QDialog):
    def __init__(self):
        super(GravityWallBaseDialog, self).__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("基礎厚さ入力")
        layout = QtGui.QGridLayout()

        # 厚みのみを指定
        layout.addWidget(QtGui.QLabel("基礎の厚み D (mm):"), 0, 0)
        self.input_d = QtGui.QLineEdit("100.0")
        layout.addWidget(self.input_d, 0, 1)

        btn_box = QtGui.QDialogButtonBox(QtGui.QDialogButtonBox.Ok | QtGui.QDialogButtonBox.Cancel)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box, 1, 0, 1, 2)

        self.setLayout(layout)

    def get_value(self):
        return float(self.input_d.text())

class GravityWallBaseCommand:
    def GetResources(self):
        current_dir = os.path.dirname(__file__)
        icon_path = os.path.normpath(os.path.join(current_dir, "..", "icons", "base.png"))
        return {
            'Pixmap': icon_path,
            'MenuText': "選択した擁壁に基礎を作成",
            'ToolTip': "擁壁の底面から四方に100mm広げた基礎を作成します"
        }

    def Activated(self):
        # 選択されているオブジェクトを取得
        selection = FreeCADGui.Selection.getSelection()
        if not selection:
            QtGui.QMessageBox.warning(None, "警告", "対象となる擁壁モデルを選択してください。")
            return

        obj = selection[0]
        if not hasattr(obj, "Shape"):
            return

        # ダイアログを表示して厚みだけ取得
        form = GravityWallBaseDialog()
        if form.exec_() == QtGui.QDialog.Accepted:
            thickness = form.get_value()
            self.create_auto_base(obj, thickness)

    def create_auto_base(self, target_obj, bd):
        # 1. 擁壁の形状からバウンディングボックスを取得
        bbox = target_obj.Shape.BoundBox
        
        # 2. 四方に100mmプラスする (片側10cm = 100mm)
        margin = 100.0
        x_min = bbox.XMin - margin
        x_max = bbox.XMax + margin
        y_min = bbox.YMin - margin
        y_max = bbox.YMax + margin
        
        # 基礎の幅と延長を計算
        bw = x_max - x_min
        bl = y_max - y_min
        
        # 3. 基礎の作成
        # 配置位置は擁壁の底面（Z=0と仮定）から厚み分下げる
        p1 = App.Vector(x_min, y_min, -bd)
        base_box = Part.makeBox(bw, bl, bd, p1)

        doc = App.activeDocument()
        obj_name = "Base_" + target_obj.Label
        obj = doc.addObject("Part::Feature", obj_name)
        obj.Shape = base_box
        
        # 見栄えの調整
        obj.ViewObject.ShapeColor = (0.7, 0.7, 0.7)
        obj.ViewObject.Transparency = 20 # 少し透明にすると重なりが見やすい
        
        doc.recompute()

    def IsActive(self):
        return len(FreeCADGui.Selection.getSelection()) > 0

# コマンドの登録
FreeCADGui.addCommand('GravityWallBase_Create', GravityWallBaseCommand())