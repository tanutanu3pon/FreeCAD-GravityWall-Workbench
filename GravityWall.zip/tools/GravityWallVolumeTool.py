# -*- coding: utf-8 -*-
import FreeCAD as App
import FreeCADGui
import os
from PySide import QtGui

class GravityWallVolumeCommand:
    def GetResources(self):
        # このファイルがあるフォルダ(tools)の1つ上にあるicons/volume.pngを取得
        current_dir = os.path.dirname(__file__)
        icon_path = os.path.normpath(os.path.join(current_dir, "..", "icons", "volume.png"))
        
        return {
            'Pixmap': icon_path,
            'MenuText': "体積を計算",
            'ToolTip': "選択した擁壁の体積(m3)を表示します"
        }

    def Activated(self):
        # 選択されているオブジェクトを取得
        selection = FreeCADGui.Selection.getSelection()
        
        if not selection:
            QtGui.QMessageBox.warning(None, "警告", "体積を計算するオブジェクトを選択してください。")
            return

        obj = selection[0]
        if hasattr(obj, "Shape"):
            # 体積(mm3)を取得して m3に変換
            vol_mm3 = obj.Shape.Volume
            vol_m3 = vol_mm3 / 1e9
            
            QtGui.QMessageBox.information(None, "体積計算結果", 
                "オブジェクト名: {}\n体積: {:.4f} m3".format(obj.Label, vol_m3))
        else:
            QtGui.QMessageBox.warning(None, "エラー", "形状データがないため計算できません。")

    def IsActive(self):
        return len(FreeCADGui.Selection.getSelection()) > 0

# コマンドの登録
FreeCADGui.addCommand('GravityWallVolume_Create', GravityWallVolumeCommand())