# -*- coding: utf-8 -*-
import FreeCAD as App
import FreeCADGui
import Part
import math
import os
from PySide import QtGui, QtCore

# --- 入力窓（ダイアログ）クラス ---
class GravityWallCurveDialog(QtGui.QDialog):
    def __init__(self):
        super(GravityWallCurveDialog, self).__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("単曲線・折れ線配置設定 (幾何一致版)")
        layout = QtGui.QGridLayout()
        layout.addWidget(QtGui.QLabel("半径 R (mm):"), 0, 0)
        self.input_r = QtGui.QLineEdit("100000.0")
        layout.addWidget(self.input_r, 0, 1)
        layout.addWidget(QtGui.QLabel("分割数:"), 1, 0)
        self.input_seg = QtGui.QLineEdit("10")
        layout.addWidget(self.input_seg, 1, 1)
        btn_box = QtGui.QDialogButtonBox(QtGui.QDialogButtonBox.Ok | QtGui.QDialogButtonBox.Cancel)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box, 2, 0, 1, 2)
        self.setLayout(layout)

    def get_values(self):
        try:
            return float(self.input_r.text()), int(self.input_seg.text())
        except:
            return 100000.0, 10

class GravityWallCurveCommand:
    def GetResources(self):
        current_dir = os.path.dirname(__file__)
        icon_path = os.path.normpath(os.path.join(current_dir, "..", "icons", "curve.png"))
        return {
            'Pixmap': icon_path,
            'MenuText': "直線的な擁壁を指定のRと分割数にしたがって曲線的に配置します。",
            'ToolTip': "トレランスの限界と天端での重なりが生じるため簡易計算として使用してください。"
        }

    def Activated(self):
        selection = FreeCADGui.Selection.getSelection()
        if not selection:
            QtGui.QMessageBox.warning(None, "警告", "対象となる直線擁壁モデルを選択してください。")
            return

        target_obj = selection[0]
        form = GravityWallCurveDialog()
        if form.exec_() == QtGui.QDialog.Accepted:
            r, segments = form.get_values()
            self.create_curved_walls(target_obj, r, segments)

    def create_curved_walls(self, target_obj, r, segments):
        doc = App.activeDocument()
        bbox = target_obj.Shape.BoundBox
        wall_len = bbox.YMax - bbox.YMin
        front_x = 0.0 

        # 1. 角度計算（円弧の長さを基準にする）
        total_angle = wall_len / r
        seg_angle = total_angle / segments

        system_group = doc.addObject("App::DocumentObjectGroup", "CurvedWallSystem")

        # --- 単曲線（参照用） ---
        arc_start = App.Vector(r * (1 - math.cos(0)), r * math.sin(0), 0)
        arc_end = App.Vector(r * (1 - math.cos(total_angle)), r * math.sin(total_angle), 0)
        mid_angle = total_angle / 2.0
        arc_mid = App.Vector(r * (1 - math.cos(mid_angle)), r * math.sin(mid_angle), 0)
        
        try:
            arc_shape = Part.Arc(arc_start, arc_mid, arc_end).toShape()
            arc_feat = doc.addObject("Part::Feature", "Reference_Arc")
            arc_feat.Shape = arc_shape
            arc_feat.ViewObject.LineColor = (0.0, 0.0, 1.0) # 青
            system_group.addObjects([arc_feat])
        except:
            pass

        current_y_in_original = bbox.YMin

        for i in range(segments):
            # 2. 角度から「円周上の正確な座標」を計算
            angle_a = i * seg_angle
            angle_b = (i + 1) * seg_angle
            
            # 座標計算式: x = R * (1 - cosθ), y = R * sinθ
            p_a = App.Vector(r * (1 - math.cos(angle_a)), r * math.sin(angle_a), 0)
            p_b = App.Vector(r * (1 - math.cos(angle_b)), r * math.sin(angle_b), 0)

            # 3. 弦の作成（赤）
            chord_line = Part.LineSegment(p_a, p_b)
            chord_feat = doc.addObject("Part::Feature", "Chord_{:02d}".format(i))
            chord_feat.Shape = chord_line.toShape()
            chord_feat.ViewObject.LineColor = (1.0, 0.0, 0.0)
            system_group.addObjects([chord_feat])

            # 4. カット延長を「弦の長さ」に動的更新
            # これをしないと、角度は合っても長さがズレます
            current_chord_len = (p_b.sub(p_a)).Length
            
            cutter = Part.makeBox(bbox.XMax-bbox.XMin + 4000, current_chord_len, bbox.ZMax-bbox.ZMin + 4000, 
                                  App.Vector(bbox.XMin-2000, current_y_in_original, bbox.ZMin-2000))
            wall_shape = target_obj.Shape.common(cutter)
            
            # 5. 配置
            vec_dir = p_b.sub(p_a)
            angle = math.degrees(math.atan2(vec_dir.y, vec_dir.x)) - 90.0
            rot = App.Rotation(App.Vector(0,0,1), angle)
            placement = App.Placement(p_a, rot)
            
            local_offset = App.Vector(-front_x, -current_y_in_original, 0)
            placement.move(placement.Rotation.multVec(local_offset))
            
            wall_feat = doc.addObject("Part::Feature", "Wall_{:02d}".format(i))
            wall_feat.Shape = wall_shape
            wall_feat.Placement = placement
            system_group.addObjects([wall_feat])
            
            # 次のブロックのために元のY位置を進める
            current_y_in_original += current_chord_len

        target_obj.ViewObject.hide()
        doc.recompute()

FreeCADGui.addCommand('GravityWallCurve_Create', GravityWallCurveCommand())