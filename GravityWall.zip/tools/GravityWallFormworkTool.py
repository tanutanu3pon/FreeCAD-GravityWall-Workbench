# -*- coding: utf-8 -*-
import FreeCAD as App
import FreeCADGui
import os
from PySide import QtGui

class GravityWallFormworkCommand:
    def GetResources(self):
        current_dir = os.path.dirname(__file__)
        icon_path = os.path.normpath(os.path.join(current_dir, "..", "icons", "formwork.png"))
        return {'Pixmap': icon_path, 'MenuText': "面積の内訳計測", 'ToolTip': "座標から全ての面を特定します"}

    def Activated(self):
        selection = FreeCADGui.Selection.getSelection()
        if not selection: return
        obj = selection[0]
        if not hasattr(obj, "Shape"): return

        faces = obj.Shape.Faces
        # 1. 全ての面の「中心点」の座標をリスト化
        face_data = []
        for f in faces:
            c = f.CenterOfMass
            face_data.append({'face': f, 'x': c.x, 'y': c.y, 'z': c.z, 'area': f.Area / 1e6})

        # 2. あなたのロジックをそのまま適用（ソートして名前を割り当てる）
        
        # Z軸（上下）：Z値でソート
        faces_z = sorted(face_data, key=lambda d: d['z'])
        bottom_face = faces_z[0]  # Z最小
        top_face = faces_z[-1]    # Z最大

        # 残りの面から、Y軸（手前・奥）：Y値でソート
        remaining = [d for d in face_data if d not in [bottom_face, top_face]]
        faces_y = sorted(remaining, key=lambda d: d['y'])
        front_side = faces_y[0]   # Y最小（手前）
        back_side = faces_y[-1]   # Y最大（奥）

        # さらに残った面から、X軸（前面・背面）：X値でソート
        remaining = [d for d in remaining if d not in [front_side, back_side]]
        faces_x = sorted(remaining, key=lambda d: d['x'])
        back_slope = faces_x[0]   # X最小（背面）
        front_slope = faces_x[-1] # X最大（前面）

        # 3. 結果の表示
        results = [
            ("面1: 底面", bottom_face),
            ("面2: 天端面", top_face),
            ("面3: 奥の断面", back_side),
            ("面4: 手前の断面", front_side),
            ("面5: 前面側の勾配面", front_slope),
            ("面6: 背面側の勾配面", back_slope)
        ]

        msg = "【擁壁 表面積内訳（最終回答）】\n" + "="*45 + "\n"
        total = 0.0
        for name, data in results:
            total += data['area']
            msg += "{0:<15}: {1:>10.3f} m2\n".format(name, data['area'])
        
        msg += "="*45 + "\n"
        msg += "全表面積 合計: {0:>10.3f} m2".format(total)
        
        self.show_results(msg)

    def show_results(self, text):
        dialog = QtGui.QDialog()
        dialog.setWindowTitle("計測結果")
        dialog.setMinimumSize(500, 400)
        layout = QtGui.QVBoxLayout(dialog)
        text_edit = QtGui.QTextEdit()
        text_edit.setReadOnly(True)
        text_edit.setPlainText(text)
        text_edit.setFont(QtGui.QFont("MS Gothic", 10))
        layout.addWidget(text_edit)
        btn = QtGui.QPushButton("閉じる")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        dialog.exec_()

    def IsActive(self): return len(FreeCADGui.Selection.getSelection()) > 0

FreeCADGui.addCommand('GravityWallFormwork_Create', GravityWallFormworkCommand())