# -*- coding: utf-8 -*-
commands = [
    'GravityWall_Create',
    'GravityWallCurve_Create',    # ← カーブツールを追加
    'GravityWallBase_Create',
    'GravityWallVolume_Create',
    'GravityWallFormwork_Create'
]