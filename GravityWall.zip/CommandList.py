# -*- coding: utf-8 -*-
commands = [
    'GravityWall_Create',
    'GravityWallVolume_Create',
    'GravityWallFormwork_Create'  # ← 追加
]